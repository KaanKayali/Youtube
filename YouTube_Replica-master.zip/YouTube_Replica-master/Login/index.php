<?php
    header("Location: register.php");
?>